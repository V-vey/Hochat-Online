<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'order_type' => $this->order_type,
            'status' => $this->status,
            'delivery_fee' => (float) $this->delivery_fee,
            'total_amount' => (float) $this->total_amount,
            'scheduled_time' => $this->scheduled_time,
            'created_at' => $this->created_at,
            'customer' => $this->whenLoaded('user', fn () => [
                'name' => $this->user->name,
                'phone' => $this->user->phone,
                'address' => $this->user->address,
            ]),
            'items' => OrderItemResource::collection($this->whenLoaded('orderItems')),
        ];
    }
}
