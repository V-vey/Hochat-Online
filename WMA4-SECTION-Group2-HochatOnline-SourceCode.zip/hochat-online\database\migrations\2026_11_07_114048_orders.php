<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->enum('order_type', ['Dine-In', 'Delivery']);
            $table->enum('status', ['Pending', 'Preparing', 'Ready', 'Completed', 'Cancelled'])->default('Pending');
            $table->decimal('total_amount', 10, 2);
            $table->dateTime('order_date')->useCurrent();
            $table->dateTime('scheduled_time')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
